$(document).ready(function() {
    $(window).scroll(function() {
      if($(this).scrollTop() > 300) { 
          $('.navbar').addClass('solid');
      } else {
          $('.navbar').removeClass('solid');
      }
    });
});